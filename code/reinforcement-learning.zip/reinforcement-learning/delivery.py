import numpy as np
import random
from grid_environment import *

# Q-Learning algorithm
def q_learning(env, episodes=100, alpha=0.1, gamma=0.95, epsilon=0.1):
    state_space = env.size * env.size  # total number of states
    action_space = env.action_space  

    # initialize Q-table
    q_table = np.zeros((state_space, action_space))
    
    rewards_per_episode = []
    
    for episode in range(episodes):
        state = env.reset()
        total_reward = 0
        
        while not env.is_done:
            # epsilon-greedy policy
            if random.uniform(0, 1) < epsilon:
                action = random.randint(0, 3)  # explore
            else:
                action = np.argmax(q_table[state])  # exploit
            
            reward = env.step(action)
            next_state = env.get_state()
            total_reward += reward
            
            # Q-learning update
            best_next_action = np.argmax(q_table[next_state])
            q_table[state, action] = q_table[state, action] + alpha * (
                reward + gamma * q_table[next_state, best_next_action] - q_table[state, action]
            )
            
            state = next_state
        
        rewards_per_episode.append(total_reward)
        if episode % 10 == 0:
            print(f"Episode {episode}, Total Reward: {total_reward}")
    
    return q_table, rewards_per_episode



def print_policy(q_table, env):
    '''print the learned policy'''
    policy = np.zeros((env.size, env.size), dtype=int)
    arrows = ['↑', '→', '↓', '←']
    
    for i in range(env.size):
        for j in range(env.size):
            state = i * env.size + j # linear position
            action = np.argmax(q_table[state])
            policy[i, j] = action
            
    print("Learned Policy:")
    for i in range(env.size):
        for j in range(env.size):
            if [i, j] == env.obstacle_pos:
                print('▩', end=' ')
            elif [i, j] == env.goal_pos:
                print('⨀', end=' ')
            else:
                print(arrows[policy[i, j]], end=' ')
        print()



# test the learned policy
def test_policy(env, q_table):
    state = env.reset()
    steps = 0
    
    print("Testing policy:")
    env.render()
    
    while not env.is_done and steps < 20:
        action = np.argmax(q_table[state])
        env.step(action)
        state = env.get_state()
        env.render()
        steps += 1
        
    if env.is_done:
        print(f"Goal reached in {steps} steps!")
    else:
        print("Failed to reach goal in the maximum steps allowed.")



if __name__ == "__main__":
  env = GridEnvironment()
  q_table, rewards = q_learning(env, episodes=200)
  print_policy(q_table, env)
  test_policy(env, q_table)