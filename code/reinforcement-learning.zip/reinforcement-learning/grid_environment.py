import numpy as np
import random

class GridEnvironment:
    def __init__(self, size=10, actions=4, obstacles=2):
        self.size = size
        self.action_space = actions
        self.agent_pos = [0, 0]  # Start at top-left
        self.goal_pos = [size-1, size-1]  # Goal at bottom-right
        self.obstacle_pos = [] # empty list of obstacles
        self.set_obstacles(obstacles)
        self.is_done = False

    def set_obstacles(self, obstacles):
        for i in range(obstacles):
            x = random.randint(1, self.size-1)
            y = random.randint(1, self.size-1)
            self.obstacle_pos.append([x, y])  #  obstacle

    def reset(self):
        self.agent_pos = [0, 0]
        self.is_done = False
        return self.get_state()
    
    def get_state(self):
        # State is represented as a single number (row * size + col)
        return self.agent_pos[0] * self.size + self.agent_pos[1]
    
    def step(self, action):
        # actions: 0 is up, 1 is right, 2 is down, 3 is left
        directions = [[-1, 0], [0, 1], [1, 0], [0, -1]]
        
        # move agent
        new_pos = [self.agent_pos[0] + directions[action][0], 
                  self.agent_pos[1] + directions[action][1]]
        
        reward = -1  # penalty for each step
        
        # check boundary
        if 0 <= new_pos[0] < self.size and 0 <= new_pos[1] < self.size:
            collision = False
            # check obstacle
            for obstacle in self.obstacle_pos:
                if new_pos == obstacle:
                    collision = True
            if not collision:
                self.agent_pos = new_pos
            else:
                reward = -10  # penalty for hitting obstacle
        
   
        if self.agent_pos == self.goal_pos:
            reward = 100  # reward for reaching goal
            self.is_done = True
  
        
        return reward

    def render(self):
        grid = np.zeros((self.size, self.size))
        grid = grid.astype(str)
        # mark obstacles
        for obstacle in self.obstacle_pos:
            grid[obstacle[0], obstacle[1]] = "▩"
        
        # mark goal
        grid[self.goal_pos[0], self.goal_pos[1]] = "⨀"

        # mark agent
        grid[self.agent_pos[0], self.agent_pos[1]] = "⛟"
        
        print()
        for row in grid:
            for element in row:
                if element == "0.0":
                    element = "▢"
                print(element + " ", end="")
            print()

        print()

        
        
