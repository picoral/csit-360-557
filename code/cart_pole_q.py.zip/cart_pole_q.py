import gymnasium as gym
import random
import numpy as np

def get_discrete_state(pole_angle, state_space):
    # episode terminates if the pole angle is not in the range (-.2095, .2095)
    angle = int(pole_angle * (state_space/2))
    if angle < 0:
        index = state_space + angle
    else:
        index = angle
    return index

def main():
    # Initialise the environment
    env = gym.make("CartPole-v1", render_mode="human")
    env.action_space.seed(123)

    learning_rate = 0.1 # alpha
    discount = 0.95 # gamma
    episodes = 100
    epsilon = 0.1
    state_space = 2000
    action_space = env.action_space.n

    # initialize Q-table
    #q_table = np.zeros((state_space, action_space))
    q_table = np.random.uniform(low=0, high=1, size = (state_space, action_space))
 
 
    for episode in range(episodes):
        step_count = 0
        # Reset the environment to generate the first observation
        observation, _ = env.reset(seed=123)
        total_reward = 0
        terminated = False
        truncated = False

        while not (terminated or truncated):
            step_count += 1
            # this is where you would insert your policy
            state = get_discrete_state(observation[2], state_space)
            
            # epsilon-greedy policy
            if random.uniform(0, 1) < epsilon:
                # 0 is left, 1 is right
                action = random.randint(0, 1)  # explore
            else:
                action = np.argmax(q_table[state])  # exploit

            # step (transition) through the environment with the action
            # receiving the next observation, reward and if the episode has terminated or truncated
            observation, reward, terminated, truncated, info = env.step(action)

            message = f"step {step_count} -- x cart position: {observation[0]}, "
            message += f"x cart velocity: {observation[1]}, "
            message += f"pole angle (rad): {observation[2]}, "
            message += f"pole angular velocity: : {observation[3]}, "
            message += f"reward: {reward}"

            #print(message)
            next_state = get_discrete_state(observation[2], state_space)
            total_reward += reward
            
            # Q-learning update
            best_next_action = np.argmax(q_table[next_state])
            q_table[state, action] = q_table[state, action] + learning_rate * (
                reward + discount * q_table[next_state, best_next_action] - q_table[state, action]
            )
            
            state = next_state

        print(f"Episode {episode}, Total Reward: {total_reward}")

    env.close()

main()