import gymnasium as gym
import random

def main():
    # Initialise the environment
    env = gym.make("CartPole-v1", render_mode="human")
    env.action_space.seed(123)


    # Reset the environment to generate the first observation
    observation, info = env.reset(seed=42)
    done = False
    step_count = 0

    while not done:
        step_count += 1
        # this is where you would insert your policy
        # 0 is left, 1 is right
        action = random.randint(0, 1)

        # step (transition) through the environment with the action
        # receiving the next observation, reward and if the episode has terminated or truncated
        observation, reward, terminated, truncated, info = env.step(action)


        message = f"step {step_count} -- x cart position: {observation[0]}, "
        message += f"x cart velocity: {observation[1]}, "
        message += f"pole angle (rad): {observation[2]}, "
        message += f"pole angular velocity: : {observation[2]}, "
        message += f"reward: {reward}"

        print(message)
        print(info)

        # If the episode has ended then we can reset to start a new episode
        if terminated or truncated:
            done = True
            observation, info = env.reset(seed=123, options={"low": -0.1, "high": 0.1})

    env.close()

main()