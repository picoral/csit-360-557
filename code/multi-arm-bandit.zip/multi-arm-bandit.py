from bandit import *

# compare different exploration rates
def compare_epsilons(epsilons=[0, 0.01, 0.1, 0.5], runs=2000, k_arms=10):
    for epsilon in epsilons:
        bandit = Bandit(k_arms=k_arms, epsilon=epsilon, runs=runs)
        bandit.run()
        bandit.print_results()
    
if __name__ == "__main__":
    # run the bandit with 10 arms, epsilon=0.1, and 2000 trials
    bandit = Bandit(k_arms=10, epsilon=0.1, runs=2000)
    compare_epsilons()