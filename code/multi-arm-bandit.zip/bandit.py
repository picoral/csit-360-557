import numpy as np
import random

class Bandit:
    def __init__(self, k_arms=10, epsilon=0.1, runs=2000):
        self.k_arms = k_arms
        self.epsilon = epsilon
        self.runs = runs
        
        # true reward probabilities for each arm (unknown to the agent)
        self.true_values = np.random.normal(0, 1, k_arms)
        
        # estimated value of each arm (updated by the agent)
        self.estimated_values = np.zeros(k_arms)
        
        # how many times each arm was pulled
        self.arm_counts = np.zeros(k_arms)
        
        # store rewards
        self.rewards = []
    
    def pull_arm(self, arm):
        """Simulate pulling an arm and getting a reward"""
        return np.random.normal(self.true_values[arm], 1)
    
    def select_arm(self):
        """Use epsilon-greedy strategy to select an arm"""
        if random.random() < self.epsilon:
            # exploration: randomly select an arm
            return random.randint(0, self.k_arms - 1)
        else:
            # exploitation: select the arm with highest estimated value
            return np.argmax(self.estimated_values)
    
    def update_estimation(self, arm, reward):
        """Update the estimated value of the arm based on the reward"""
        self.arm_counts[arm] += 1
        # incremental update rule:
        # new estimate = old estimate + (reward - old estimate) / count
        self.estimated_values[arm] += (reward - self.estimated_values[arm]) / self.arm_counts[arm]
    
    def run(self):
        """Run the bandit algorithm"""
        total_reward = 0
        
        for i in range(self.runs):
            # select an arm using epsilon-greedy
            arm = self.select_arm()
            
            # get reward from pulling that arm
            reward = self.pull_arm(arm)
            
            # update total reward
            total_reward += reward
            
            # store average reward up to this point
            self.rewards.append(total_reward / (i + 1))
            
            # update our estimate of the arm's value
            self.update_estimation(arm, reward)

    def print_results(self):
        print(f"True values of arms: {self.true_values}")
        print(f"Estimated values: {self.estimated_values}")
        print(f"Arm pull counts: {self.arm_counts}")
        print(f"Best arm: {np.argmax(self.true_values)} (true value: {np.max(self.true_values):.4f})")
        print(f"Arm selected most: {np.argmax(self.arm_counts)}")
        

